# SMS Lab — Safe Demo

This project is a consent-based SMS workflow UI with mock responses only.

## Files
- `index.html` — responsive dashboard; simulates test progress locally.
- `api/smsb.js` — optional Vercel serverless mock endpoint; never contacts an SMS provider.

## Deploy
1. Upload this folder to a GitHub repository.
2. Import the repository into Vercel.
3. Deploy. The root `index.html` is served as the site and `/api/smsb` returns mock JSON.

The supplied SMS-bombing endpoint is intentionally not integrated. For real messaging, use a reputable SMS provider's official API with verified opt-in recipients, rate limits, and abuse controls.
