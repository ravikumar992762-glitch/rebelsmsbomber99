// Safe demo endpoint: returns a mock response and never sends SMS.
export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });

  const body = req.body || {};
  const phone = String(body.number || "").replace(/\D/g, "");
  if (phone.length < 7 || phone.length > 15) {
    return res.status(400).json({ success: false, error: "Invalid test number" });
  }

  return res.status(200).json({
    success: true,
    mode: "simulation",
    message: "Mock response only. No SMS was sent.",
    maskedNumber: `••••${phone.slice(-4)}`
  });
}
